#include<iostream>
using namespace std;
#include<math.h>
#include<cmath>

int main()
{
	float x, y, z;
	cout << "Nhap x = ";
	cin >> x;
	cout << "Nhap y = ";
	cin >> y;
	cout << "Nhap z = ";
	cin >> z;
	if (x <= y && y <= z)
		cout << "Bat dang thuc dung" << endl;
	else
		cout << "Bat dang thuc khong dung" << endl;
	return 0;
}