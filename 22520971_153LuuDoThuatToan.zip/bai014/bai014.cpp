#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	float x;
	cout << "x = ";
	cin >> x;
	float x2 = x * x;
	float x4 = x2 * x2;
	double x8 = x4 * x4;
	double x16 = x8 * x8;
	double x32 = x16 * x16;
	cout << "x32 = " << x32 << endl;
	return 0;
}