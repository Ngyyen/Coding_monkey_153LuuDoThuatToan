#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	int a, b;
	cout << "a = ";
	cin >> a;
	cout << "b = ";
	cin >> b;
	a = a + b;
	b = a - b;
	a = a - b;
	cout << "Hai so a va b la: " << a << " va " << b << endl;
	return 0;
}