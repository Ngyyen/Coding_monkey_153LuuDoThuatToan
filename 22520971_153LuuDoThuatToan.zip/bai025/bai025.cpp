#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	int a, b;
	cout << "a = ";
	cin >> a;
	cout << "b = ";
	cin >> b;
	int c = a;
	a = b;
	b = c;
	cout << "Hai so a va b la: " << a << " va " << b << endl;
	return 0;
}