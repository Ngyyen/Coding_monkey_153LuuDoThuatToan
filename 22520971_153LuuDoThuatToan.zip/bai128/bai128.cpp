#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	float a;
	cout << "Nhap a = ";
	cin >> a;
	float b;
	cout << "Nhap b = ";
	cin >> b;
	if (a > b)
	{
		float temp = a;
		a = b;
		b = temp;
	}
	cout << "Gia tri tang dan la: " << a << ", " << b << endl;
	return 0;
}