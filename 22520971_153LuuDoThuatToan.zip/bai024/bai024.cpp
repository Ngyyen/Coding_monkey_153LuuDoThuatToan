#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	int n;
	cout << "n = ";
	cin >> n;
	int ht = (n / 100) % 10;
	cout << "Chu so hang tram la " << ht << endl;
	return 0;
}