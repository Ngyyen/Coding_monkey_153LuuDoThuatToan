#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	float x;
	cout << "x = ";
	cin >> x;
	int n;
	cout << "n = ";
	cin >> n;
	float s = -1;
	float t = 1;
	int m = 1;
	int i = 2;
	int dau = 1;
	while (i <= (2 * n))
	{
		t = t * x * x;
		m = m * i * (i - 1);
		s = s + dau * (float)(t / m);
		i = i + 2;
		dau = -dau;
	}
	cout << "S(" << x << "," << n << ") = " << s << endl;
	return 0;
}