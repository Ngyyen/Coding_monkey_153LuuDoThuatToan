#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	float a;
	cout << "Nhap a = ";
	cin >> a;
	float b;
	cout << "Nhap b = ";
	cin >> b;
	if (a < 0)
		a = -a;
	if (b < 0)
		b = -b;
	cout << "abs cua a = " << a << endl;
	cout << "abs cua b = " << b << endl;
	return 0;
}