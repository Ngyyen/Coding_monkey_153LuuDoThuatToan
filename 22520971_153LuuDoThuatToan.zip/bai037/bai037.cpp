#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	int n;
	cout << "n = ";
	cin >> n;
	int t = 0;
	for (int i = 1; i <= n; i++)
	{
		t = t + i * i * i;
	}
	cout << "T(" << n << ") = " << t << endl;
	return 0;
}