#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	int x1, y1, x2, y2;
	cout << "Nhap toa do diem A:" << endl;
	cout << "x1 = ";
	cin >> x1;
	cout << "y1 = ";
	cin >> y1;
	cout << "Nhap toa do diem B:" << endl;
	cout << "x2 = ";
	cin >> x2;
	cout << "y2 = ";
	cin >> y2;
	float d = sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
	cout << "Khoang cach giua hai diem A va B la: " << d << endl;
	return 0;
}