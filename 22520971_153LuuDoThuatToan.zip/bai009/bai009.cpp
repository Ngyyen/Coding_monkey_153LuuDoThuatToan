#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	float r;
	cout << "Ban kinh = ";
	cin >> r;
	float n;
	cout << "So canh noi tiep = ";
	cin >> n;
	double s = (3.14*n * r * r * sin(2 * 3.14 / n)) / 2;
	cout << "Dien tich da giac deu = " << s << endl;
	return 0;
}