#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	float x;
	cout << "x = ";
	cin >> x;
	int n;
	cout << "n = ";
	cin >> n;
	float s = x;
	float t = x;
	int i = 3;
	while (i <= (2 * n + 1))
	{
		t = t * x * x;
		s = s + t;
		i = i + 2;
	}
	cout << "S(" << x << "," << n << ") = " << s << endl;
	return 0;
}