#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	float a;
	cout << "Nhap a = ";
	cin >> a;
	float b;
	cout << "Nhap b = ";
	cin >> b;
	float lc = a;
	if (lc < b)
		lc = b;
	cout << "Gia tri lon nhat la  " << lc << endl;
	return 0;
}