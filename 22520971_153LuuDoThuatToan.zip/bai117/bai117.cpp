#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	int n;
	cout << "Nhap n = ";
	cin >> n;
	int att = -1;
	int at = 3;
	int i = 2;
	int ahh;
	while (i <= n)
	{
		ahh = (5 * pow(2, i)) + (5 * at) - att;
		i = i + 1;
		att = at;
		at = ahh;
	}
	cout << "a(" << n << ") = " << ahh << endl;
	return 0;
}