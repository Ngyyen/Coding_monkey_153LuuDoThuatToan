#include<iostream>
#include<math.h>
using namespace std;

int main()
{
	int n;
	cout << "n = ";
	cin >> n;
	int s = 0;
	int t = n;
	int dv;
	while (t != 0)
	{
		dv = t % 10;
		s = s + dv;
		t = t / 10;
	}
	cout << "Tong cac chu so cua " << n << " la: " << s;
	return 0;
}