#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	float f;
	cout << "Do F = ";
	cin >> f;
	float c = (5 * (f - 32)) / 9;
	cout << "Do C = " << c << endl;
	return 0;
}