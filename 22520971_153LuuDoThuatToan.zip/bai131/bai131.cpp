#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	float xa, ya, xb, yb, xc, yc;
	cout << "Nhap toa do diem A:" << endl;
	cout << "xa = ";
	cin >> xa;
	cout << "ya = ";
	cin >> ya;
	cout << "Nhap toa do diem B:" << endl;
	cout << "xb = ";
	cin >> xb;
	cout << "yb = ";
	cin >> yb;
	cout << "Nhap toa do diem C:" << endl;
	cout << "xc = ";
	cin >> xc;
	cout << "yc = ";
	cin >> yc;
	float d1 = sqrt((xb - xa) * (xb - xa) + (yb - ya) * (yb - ya));
	float d2 = sqrt((xc - xb) * (xc - xb) + (yc - yb) * (yc - yb));
	float d3 = sqrt((xc - xa) * (xc - xa) + (yc - ya) * (yc - ya));
	if (d1 + d2 > d3 && d1 + d3 > d2 && d2 + d3 > d1)
		cout << "La tam giac" << endl;
	else
		cout << "Khong la tam giac" << endl;
	return 0;
}