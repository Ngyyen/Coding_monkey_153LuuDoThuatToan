#include<iostream>
using namespace std;
#include<math.h>
#include<cmath>

int main()
{
	int n;
	cout << "n = ";
	cin >> n;
	int s = 0;
	int i = 1;
	while (i < n)
	{
		if (n % i == 0)
		{
			s = s + i;
		}
		i = i + 1;
	}
	if (s == n)
	{
		cout << "So " << n << " la so hoan thien" << endl;
	}
	else
		cout << "So " << n << " khong la so hoan thien" << endl;
	return 0;
}