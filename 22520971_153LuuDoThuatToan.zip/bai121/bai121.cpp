#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	int n = 0;
	cout << "Nhap n = ";
	cin >> n;
	int ftt = 1;
	int ft = 1;
	int i = 2;
	int fhh = 0;
	while (i <= n)
	{
		fhh = ftt + ft;
		ftt = ft;
		ft = fhh;
		i = i + 1;
	}
	cout << "f(" << n << ") = " << fhh << endl;
	return 0;
}