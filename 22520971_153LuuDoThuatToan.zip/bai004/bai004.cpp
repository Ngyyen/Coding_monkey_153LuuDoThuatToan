#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	float r;
	cout << "Ban kinh = ";
	cin >> r;
	double dt = 4 * 3.14 * r * r;
	cout << "Dien tich xung quanh hinh cau = " << dt << endl;
	return 0;
}