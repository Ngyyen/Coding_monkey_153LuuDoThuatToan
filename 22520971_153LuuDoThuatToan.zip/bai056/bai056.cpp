#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	int n;
	cout << "n = ";
	cin >> n;
	int dem = 0;
	int i = 2;
	while (i <= n)
	{
		if (n % i == 0)
			dem++;
		i = i + 2;
	}
	cout << "So uoc so chan cua " << n << " la: " << dem;
	return 0;
}