#include<iostream>
using namespace std;
#include<math.h>
#include<cmath>

int main()
{
	int m;
	cout << "Nhap m = ";
	cin >> m;
	int n;
	cout << "Nhap n = ";
	cin >> n;
	int a = abs(m);
	int b = abs(n);
	while (a * b != 0)
	{
		if (a > b)
		{
			a = a - b;
		}
		else
			b = b - a;
	}
	float kq = (float)(m * n) / (a + b);
	cout << "Boi chung nho nhat cua hai so " << m << " va " << n << " la " << kq << endl;
	return 0;
}