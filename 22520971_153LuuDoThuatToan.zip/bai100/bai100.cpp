#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	int n;
	cout << "n = ";
	cin >> n;
	float s = 0;
	int t = 1;
	int i = 1;
	while (i <= n)
	{
		t = t * i;
		s = pow(s + t, (float)1 / (i + 1));
		i = i + 1;
	}
	cout << "S(" << n << ") = " << s << endl;
	return 0;
}