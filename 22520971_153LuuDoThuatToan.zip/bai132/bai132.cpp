#include<iostream>
using namespace std;
#include<math.h>
#include<cmath>

int main()
{
	float xa, ya, xb, yb, xc, yc, xm, ym;
	cout << "Nhap toa do diem A:" << endl;
	cout << "xa = ";
	cin >> xa;
	cout << "ya = ";
	cin >> ya;
	cout << "Nhap toa do diem B:" << endl;
	cout << "xb = ";
	cin >> xb;
	cout << "yb = ";
	cin >> yb;
	cout << "Nhap toa do diem C:" << endl;
	cout << "xc = ";
	cin >> xc;
	cout << "yc = ";
	cin >> yc;
	cout << "Nhap toa do diem M:" << endl;
	cout << "xM = ";
	cin >> xm;
	cout << "yM = ";
	cin >> ym;
	float ABC = abs((float)(1 / 2) * (xa * yb + xb * yc + xc * ya - xb * ya - xc * yb - xa * yc));
	float AMB = abs((float)(1 / 2) * (xa * ym + xm * yb + xb * ya - xm * ya - xb * ym - xa * yb));
	float AMC = abs((float)(1 / 2) * (xa * ym + xm * yc + xc * ya - xm * ya - xc * ym - xa * yc));
	float BMC = abs((float)(1 / 2) * (xm * yb + xb * yc + xc * ym - xb * ym - xc * yb - xm * yc));
	float S = AMB + AMC + BMC;
	if (ABC == S)
		cout << "M nam trong tam giac ABC";
	else
		cout << "M nam ngoai tam giac ABC  ";
	return 0;
}