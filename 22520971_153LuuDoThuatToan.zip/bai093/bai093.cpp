#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	int n;
	cout << "n = ";
	cin >> n;
	float s = 0;
	int i = 1;
	while (i <= n)
	{
		s = sqrt(2 + s);
		i = i + 1;
	}
	cout << "S(" << n << ") = " << s << endl;
	return 0;
}