#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	float s = 0;
	int i = 1;
	int m = 0;
	float e = 1;
	while (e >= pow(10, -6))
	{
		m = m + i;
		e = (float)1 / m;
		s = s + e;
		i = i + 1;
	}
	cout << "S(" << i << ") = " << s << endl;
	return 0;
}