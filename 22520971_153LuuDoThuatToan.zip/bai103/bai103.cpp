#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	float s = 0;
	int i = 1;
	float e = 1;
	while (e >= pow(10, -6))
	{
		e = (float)1 / (2 * i + 1);
		s = s + e;
		i = i + 1;
	}
	cout << "S(" << i << ") = " << s << endl;
	return 0;
}