#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	int n;
	cout << "n = ";
	cin >> n;
	float s = 0;
	int i = 2;
	while (i <= n)
	{
		s = pow(s + i, (float)1 / i);
		i = i + 1;
	}
	cout << "S(" << n << ") = " << s << endl;
	return 0;
}