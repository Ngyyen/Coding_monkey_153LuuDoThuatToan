#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	float r;
	cout << "Ban kinh = ";
	cin >> r;
	double cv = 2 * 3.14 * r;
	cout << "Chu vi duong tron = " << cv << endl;
	return 0;
}