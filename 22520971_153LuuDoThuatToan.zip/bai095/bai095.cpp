#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	int n = 0;
	cout << "n = ";
	cin >> n;
	float s = 0;
	int i = n;
	while (i >= 1)
	{
		s = sqrt(i + s);
		i = i - 1;
	}
	cout << "S(" << n << ") = " << s << endl;
	return 0;
}