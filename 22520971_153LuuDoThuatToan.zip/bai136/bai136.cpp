#include<iostream>
using namespace std;
#include<math.h>
#include<cmath>

int main()
{
	int x;
	cout << "Nam x la ";
	cin >> x;
	int y;
	cout << "Nam y la ";
	cin >> y;
	int i = x;
	cout << "Cac nam nhuan la ";
	while (i <= y)
	{
		float dk1 = (i % 4 == 0 && i % 100 != 0);
		float dk2 = (i % 400 == 0);
		if (dk1 || dk2)
		{
			cout << i << " ";
		}
		i = i + 1;
	}
	return 0;
}