#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	int n;
	cout << "n = ";
	cin >> n;
	float s = 1;
	for (int i = 1; i <= n; i++)
	{
		s = s * (float)(1.0 + (float)(1.0 / (i * i)));
	}
	cout << "S(" << n << ") = " << s << endl;
	return 0;
}