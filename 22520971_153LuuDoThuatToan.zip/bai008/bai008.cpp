#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	float r;
	cout << "Ban kinh = ";
	cin >> r;
	float n;
	cout << "So canh noi tiep = ";
	cin >> n;
	double p = 2 * 3.14 * r * sin(pi / n);
	cout << "Chu vi da giac deu = " << p << endl;
	return 0;
}