#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	float x;
	cout << "x = ";
	cin >> x;
	int n;
	cout << "n = ";
	cin >> n;
	float s = 0;
	float t = 1;
	int i = 2;
	while (i <= (2 * n))
	{
		t = t * x * x;
		s = s + t;
		i = i + 2;
	}
	cout << "S(" << x << "," << n << ") = " << s << endl;
	return 0;
}