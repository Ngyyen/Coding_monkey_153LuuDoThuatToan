#include<iostream>
using namespace std;
#include<math.h>
#include<cmath>

int main()
{
	int a;
	cout << "Nhap a = ";
	cin >> a;
	int b;
	cout << "Nhap b = ";
	cin >> b;
	float x;
	if (a == 0)
	{
		if (b == 0)
		{
			cout << "Phuong trinh " << a << "x+" << b << "=0 vo so nghiem" << endl;
		}
		else
			cout << "Phuong trinh " << a << "x+" << b << "=0 vo nghiem" << endl;
	}
	else
	{
		x = (float)(-b) / a;
		cout << "Phuong trinh " << a << "x+" << b << "=0 co nghiem x = " << x << endl;
	}
	return 0;
}