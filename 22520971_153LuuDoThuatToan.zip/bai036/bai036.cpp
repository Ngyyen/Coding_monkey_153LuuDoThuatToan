#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	float x;
	cout << "x = ";
	cin >> x;
	int n;
	cout << "n = ";
	cin >> n;
	float t = 1;
	for (int i = 1; i <= n; i++)
	{
		t = t * x;
	}
	cout << "T(" << x << "," << n << ") = " << t << endl;
	return 0;
}