#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	float x;
	cout << "x = ";
	cin >> x;
	float x2 = x * x;
	float x4 = x2 * x2;
	double x8 = x4 * x4;
	double x9 = x8 * x;
	cout << "x9 = " << x9 << endl;
	return 0;
}