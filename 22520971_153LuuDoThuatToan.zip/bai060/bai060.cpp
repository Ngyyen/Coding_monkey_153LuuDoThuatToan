#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	int n;
	cout << "n = ";
	cin >> n;
	int s = 1;
	int t = n;
	while (t != 0)
	{
		int dv = t % 10;
		s = s * dv;
		t = t / 10;
	}
	cout << "Tich cac chu so cua " << n << " la: " << s;
	return 0;
}