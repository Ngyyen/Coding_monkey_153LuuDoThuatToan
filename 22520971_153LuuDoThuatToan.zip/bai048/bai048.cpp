#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	float x;
	cout << "x = ";
	cin >> x;
	int n;
	cout << "n = ";
	cin >> n;
	float s = x;
	for (int i = 1; i <= n; i++)
	{
		s = s * (x + i);
	}
	cout << "S(" << x << "," << n << ") = " << s << endl;
	return 0;
}