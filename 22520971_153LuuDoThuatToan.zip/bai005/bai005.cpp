#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	float r;
	cout << "Ban kinh = ";
	cin >> r;
	double tt = (4 * 3.14 * r * r * r) / 3;
	cout << "The tich hinh cau = " << tt << endl;
	return 0;
}