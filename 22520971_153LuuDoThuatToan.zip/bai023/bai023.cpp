#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	int n;
	cout << "n = ";
	cin >> n;
	int hc = (n % 100) / 10;
	cout << "Chu so hang chuc la " << hc << endl;
	return 0;
}