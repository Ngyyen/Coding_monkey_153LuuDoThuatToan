#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	float c;
	cout << "Do C = ";
	cin >> c;
	float f = (9 * c) / 5 + 32;
	cout << "Do F = " << f << endl;
	return 0;
}