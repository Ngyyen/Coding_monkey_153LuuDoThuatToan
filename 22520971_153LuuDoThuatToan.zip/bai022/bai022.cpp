#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	int n;
	cout << "n = ";
	cin >> n;
	int dv = n % 10;
	cout << "Chu so hang don vi la " << dv << endl;
	return 0;
}