#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	int n;
	cout << "n = ";
	cin >> n;
	float s = 0;
	for (int i = 1; i <= n; i++)
	{
		s = s + (float)sqrt(1.0 + (1.0 / (i * i)) + (1.0 / ((i + 1) * (i + 1))));
	}
	cout << "S(" << n << ") = " << s << endl;
	return 0;
}