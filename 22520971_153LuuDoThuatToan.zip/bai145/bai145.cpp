#include<iostream>
using namespace std;
#include<math.h>
#include<cmath>

int main()
{
	int n;
	cout << "n = ";
	cin >> n;
	int flag = 0;
	int i = 0;
	while (i <= n)
	{
		if (i * i == n)
		{
			flag = 1;
		}
		i = i + 1;
	}
	if (flag == 1)
	{
		cout << "So " << n << " la so chinh phuong" << endl;
	}
	else
		cout << "So " << n << " khong la so chinh phuong" << endl;
	return 0;
}