#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	int k;
	cout << "Nhap k = ";
	cin >> k;
	int at = 2;
	int bt = 1;
	int i = 2;
	int ahh = 0, bhh = 0;
	while (i <= k)
	{
		ahh = (at * at) + (2 * bt * bt);
		bhh = 2 * at * bt;
		i = i + 1;
		at = ahh;
		bt = bhh;
	}
	cout << "a(" << k << ") = " << ahh << endl;
	cout << "b(" << k << ") = " << bhh << endl;
	return 0;
}