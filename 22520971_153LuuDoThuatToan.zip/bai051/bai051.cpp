#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	int n;
	cout << "n = ";
	cin >> n;
	int s = 1;
	int i = 1;
	while (i <= n)
	{
		if (n % i == 0)
			s = s * i;
		i++;
	}
	cout << "Tich cac uoc so cua " << n << " la: " << s;
	return 0;
}