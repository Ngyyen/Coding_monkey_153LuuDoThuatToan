#include<iostream>
using namespace std;
#include<cmath>

int main()
{
	float r;
	cout << "Ban kinh = ";
	cin >> r;
	double dt = 3.14 * r * r;
	cout << "Dien tich duong tron = " << dt << endl;
	return 0;
}