#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	int n;
	cout << "n = ";
	cin >> n;
	int s = 0;
	for (int i = 1; i <= n; i++)
	{
		s = s + i * (i + 1);
	}
	cout << "S(" << n << ") = " << s << endl;
	return 0;
}