#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	float x;
	cout << "x = ";
	cin >> x;
	float x2 = x * x;
	float x4 = x2 * x2;
	double x8 = x4 * x4;
	double x10 = x8 * x2;
	double x11 = x10 * x;
	cout << "x11 = " << x11 << endl;
	return 0;
}