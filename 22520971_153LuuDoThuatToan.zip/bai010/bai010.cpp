#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	int x1, y1, x2, y2, x3, y3;
	cout << "Nhap toa do diem A:" << endl;
	cout << "x1 = ";
	cin >> x1;
	cout << "y1 = ";
	cin >> y1;
	cout << "Nhap toa do diem B:" << endl;
	cout << "x2 = ";
	cin >> x2;
	cout << "y2 = ";
	cin >> y2;
	cout << "Nhap toa do diem C:" << endl;
	cout << "x3 = ";
	cin >> x3;
	cout << "y3 = ";
	cin >> y3;
	float d1 = sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
	float d2 = sqrt((x3 - x2) * (x3 - x2) + (y3 - y2) * (y3 - y2));
	float d3 = sqrt((x3 - x1) * (x3 - x1) + (y3 - y1) * (y3 - y1));
	float p = d1 + d2 + d3;
	cout << "Chu vi tam giac = " << p << endl;
	return 0;
}