#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	int n;
	cout << "n = ";
	cin >> n;
	float s = 0;
	float t = 0;
	int i = 1;
	int dau = 1;
	while (i <= n)
	{
		t = t + i;
		s = s + dau * (float)(1 / t);
		i = i + 1;
		dau = -dau;
	}
	cout << "S(" << n << ") = " << s << endl;
	return 0;
}