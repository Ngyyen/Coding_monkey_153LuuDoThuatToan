#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	float x;
	cout << "x = ";
	cin >> x;
	float x2 = x * x;
	float x4 = x2 * x2;
	double x8 = x4 * x4;
	double x12 = x8 * x4;
	double x14 = x12 * x2;
	cout << "x14 = " << x14 << endl;
	return 0;
}