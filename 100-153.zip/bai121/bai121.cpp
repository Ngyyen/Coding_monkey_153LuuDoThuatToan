#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	int n = 0;
	cout << "Nhap n = ";
	cin >> n;
	int ftt = 1;
	int ft = 1;
	int i = 2;
	int fs = 0;
	while (i <= n)
	{
		fs = ftt + ft;
		ftt = ft;
		ft = fs;
		i = i + 1;
	}
	cout << "f(" << n << ") = " << fs << endl;
	return 0;
}