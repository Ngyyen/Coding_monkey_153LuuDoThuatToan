#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	int k;
	cout << "Nhap k = ";
	cin >> k;
	int at = 2;
	int bt = 1;
	int i = 2;
	int as = 0, bs = 0;
	while (i <= k)
	{
		as = 3 * bt + 2 * at;
		bs = at + 3 * bt;
		i = i + 1;
		at = as;
		bt = bs;
	}
	cout << "a(" << k << ") = " << as << endl;
	cout << "b(" << k << ") = " << bs << endl;
	return 0;
}