#include<iostream>
using namespace std;
#include<math.h>
#include<cmath>

int main()
{
	int n;
	cout << "Nhap n = ";
	cin >> n;
	float dk1 = (n % 4 == 0 && n % 100 != 0);
	float dk2 = (n % 400 == 0);
	if (dk1 || dk2)
		cout << "Nam " << n << " la nam nhuan" << endl;
	else
		cout << "Nam " << n << " khong la nam nhuan" << endl;
	return 0;
}