#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	int n;
	cout << "Nhap n = ";
	cin >> n;
	int at = 2;
	int i = 2;
	int as = 0;
	while (i <= n)
	{
		as = at + 2 * i + 1;
		i = i + 1;
		at = as;
	}
	cout << "a(" << n << ") = " << as << endl;
	return 0;
}