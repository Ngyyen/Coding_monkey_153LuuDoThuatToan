#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	int n;
	cout << "Nhap n = ";
	cin >> n;
	int at = -2;
	int i = 2;
	int as = 0;
	while (i <= n)
	{
		as = 5 * at + 2 * pow(3, i) - 6 * pow(7, i) + 12;
		i = i + 1;
		at = as;
	}
	cout << "a(" << n << ") = " << as << endl;
	return 0;
}