#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	float x;
	cout << "nhap x:";
	cin >> x;
	float s = 1;
	float t = 1;
	int i = 2;
	int N = 1;
	float e = 1;
	int dau = -1;
	while (e >= pow(10, -6))
	{
		t = t * x * x;
		N = N * i * (i - 1);
		e = (float)t / N;
		s = s + dau * e;
		i = i + 2;
		dau = -dau;
	}
	cout << "cos(" << x << ") = " << s << endl;
	return 0;
}