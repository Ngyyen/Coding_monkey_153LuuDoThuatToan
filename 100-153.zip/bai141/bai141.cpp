#include<iostream>
using namespace std;
#include<math.h>
#include<cmath>

int main()
{
	int n;
	cout << "n = ";
	cin >> n;
	int t = n;
	while (t >= 10)
	{
		t = t / 10;
	}
	cout << "Chu so dau tien cua so " << n << " la " << t << endl;
	return 0;
}