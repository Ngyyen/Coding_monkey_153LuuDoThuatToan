#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	int n;
	cout << "Nhap n = ";
	cin >> n;
	int att = -1;
	int at = 3;
	int i = 2;
	int as = 0;
	while (i <= n)
	{
		as = 5 * at + 6 * att;
		i = i + 1;
		att = at;
		at = as;
	}
	cout << "a(" << n << ") = " << as << endl;
	return 0;
}