#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	float x;
	cout << "nhap x:";
	cin >> x;
	float s = x;
	float t = x;
	int i = 3;
	int N = 1;
	float e = 1;
	int dau = -1;
	while (e >= pow(10, -6))
	{
		t = t * x * x;
		N = N * i * (i - 1);
		e = (float)t / N;
		s = s + dau * e;
		i = i + 2;
		dau = -dau;
	}
	cout << "sin(" << x << ") = " << s << endl;
	return 0;
}