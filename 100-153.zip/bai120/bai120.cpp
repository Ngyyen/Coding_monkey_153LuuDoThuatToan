#include<iostream>
using namespace std;
#include<math.h>

int main()
{
	int n;
	cout << "Nhap n = ";
	cin >> n;
	float at = 2;
	int i = 2;
	float as;
	while (i <= n)
	{
		as = (float)(5 * at + (float)sqrt(24 * at * at - 8));
		i = i + 1;
		at = as;
	}
	cout << "a(" << n << ") = " << as << endl;
	return 0;
}