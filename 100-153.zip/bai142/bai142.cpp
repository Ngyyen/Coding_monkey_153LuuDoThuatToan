#include<iostream>
using namespace std;
#include<math.h>
#include<cmath>

int main()
{
	int n;
	cout << "n = ";
	cin >> n;
	int b = 0;
	int t = n;
	int c;
	while (t != 0)
	{
		c = t % 10;
		b = b * 10 + c;
		t = t / 10;
	}
	cout << "So dao nguoc cua so " << n << " la " << b << endl;
	return 0;
}